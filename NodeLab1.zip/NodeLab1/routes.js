"use strict";

const express = require("express");

const items = express.Router();

const itemList = [
    {
        id: 7849,
        product: "avocado",
        price: 2,
        quantity: 3
    },
    {
        id: 7999,
        product: "pear",
        price: 1,
        quantity: 4
    },
    {
        id: 8989,
        product: "banana",
        price: 5,
        quantity: 2
    },
];

items.get("/items", function (req, res){
    res.send(itemList);
    console.log("GET request made");
});

// post method we're building here will add to the array, pushing into the itemList. Adding an object. 
items.post("/items", function (req, res){
    itemList.push(req.body);
    console.log("POST method made");
    res.send(itemList);
})

items.put("/items/:id", function(req, res){
    for( let i = 0; i < itemList.length; i++){
        if (itemList[i].id == req.params.id) {
            //req.body.id is updating everything we targeted
            itemList.splice(i, 1, req.body);
            console.log(req.body);
            console.log(req.params.id);
            res.send(itemList);
            break;
        }
    }
    console.log("PUT request made");
})

items.delete("/items/:id", function(req, res){
    for(let i = 0; i < itemList.length; i++){
        if (itemList[i] === req.params.id){
            itemList.splice(i, 1);
            res.send(itemList);
            break;
        }
    }
    console.log("DELETE request made");
});




module.exports = items;