"use strict";

const items = {
    templateUrl: "component.html",

    // this is Injecting a service
    controller: ["CartService", function (CartService) {
        const vm = this;

        CartService.getAllItems().then(response => {
            console.log(response);
            vm.itemList = response.data;
        });

        vm.deleteItem = function (item) {
            CartService.deleteItem(item).then(response => {
                vm.itemList = response.data;
                console.log(response);
            });
        };
    }]

}





angular
    .module("App")
    .component("items", items)